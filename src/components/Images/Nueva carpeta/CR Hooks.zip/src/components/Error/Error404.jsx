import React from 'react'
import error from '../../Assets/404.gif'

function Error404() {
  return (
    <div>
        <img src={error} alt=""/>
    </div>
  )
}

export default Error404