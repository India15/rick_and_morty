export const ADD_FAVORITE = "ADD_FAVORITE" 
export const REMOVE_FAVORITE = "REMOVE_FAVORITE" 
export const FILTER = "FILTER"
export const ORDER = "ORDER"